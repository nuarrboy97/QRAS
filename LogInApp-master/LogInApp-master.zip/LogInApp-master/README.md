# LogInApp
A simple registration and login app with SQLite database with attractive UI.
APK is in app/apk folder.
Suggestions are welcome. Mail me at thealteria-1@yahoo.com :)

